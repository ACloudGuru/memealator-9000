import memeify.lambda


handler = memeify.lambda.lambda_handler
